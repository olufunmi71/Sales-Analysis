Create Database SALESANALYSIS_DB 

CREATE TABLE SalesData (
OrderID INT PRIMARY KEY,
CustomerID NVARCHAR(50),
Product NVARCHAR(50),
Region NVARCHAR(50),
OrderDate DATE,
Quantity INT,
UnitPrice DECIMAL(10, 2)  -- Allows prices with decimal values like 99.99
);
-- Alter the table to change the data type of Quantity to INT
ALTER TABLE SalesData
ALTER COLUMN Quantity INT;
-- Alter the table to change the data type of UnitPrice to DECIMAL(18, 2)
ALTER TABLE SalesData
ALTER COLUMN UnitPrice DECIMAL(18, 2);

SELECT 
    OrderID, Customer_Id, Product, Region, OrderDate, Quantity, UnitPrice,
    COUNT(*) AS Count
FROM 
   [dbo].[LITA Capstone Dataset]
GROUP BY 
    OrderID, Customer_Id, Product, Region, OrderDate, Quantity, UnitPrice
HAVING 
    COUNT(*) > 1;


WITH CTE AS (
 SELECT 
        *, 
ROW_NUMBER() OVER (PARTITION BY OrderID, Customer_Id, Product, Region, OrderDate, Quantity, UnitPrice 
 ORDER BY OrderID) AS RowNum
    FROM 
        [dbo].[LITA Capstone Dataset]
)
-- Delete duplicate rows, keeping only the first occurrence
DELETE FROM CTE
WHERE RowNum > 1;


SELECT 
OrderID, Customer_Id, Product, Region, OrderDate, Quantity, UnitPrice,
 COUNT(*) AS Count
FROM 
    [dbo].[LITA Capstone Dataset]
GROUP BY 
OrderID, Customer_Id, Product, Region, OrderDate, Quantity, UnitPrice
HAVING 
COUNT(*) > 1;


-- Retreve total sales for each product category using WITH clause
WITH ProductSales AS (
 SELECT 
  Product,
SUM(CAST(Quantity AS DECIMAL(18, 2)) * CAST(UnitPrice AS DECIMAL(18, 2))) AS TotalSales
    FROM 
        [dbo].[LITA Capstone Dataset]
    GROUP BY 
        Product
)
-- Now select the results from the named "ProductSales"
SELECT * FROM ProductSales;


	-- Number of sales transactions by region using WITH clause
WITH RegionTransactions AS (
    SELECT 
        Region,
        COUNT(OrderID) AS NumberOfTransactions
    FROM 
      [dbo].[LITA Capstone Dataset]  
    GROUP BY 
        Region
)
-- Now select the results from the named "RegionTransactions"
SELECT * FROM RegionTransactions;


-- Highest selling products by total sales value using WITH clause
WITH ProductSales AS (
 SELECT 
 Product,
SUM(CAST(Quantity AS DECIMAL(18, 2)) * CAST(UnitPrice AS DECIMAL(18, 2))) AS TotalSalesValue
    FROM 
       [dbo].[LITA Capstone Dataset]
    GROUP BY 
        Product
)
-- Now select all products from the named "ProductSales" and order them by TotalSalesValue
SELECT * 
FROM ProductSales
ORDER BY TotalSalesValue DESC;

-- Total revenue per product using WITH clause
WITH ProductRevenue AS (
    SELECT 
        Product,
        SUM(CAST(Quantity AS DECIMAL(18, 2)) * CAST(UnitPrice AS DECIMAL(18, 2))) AS TotalRevenue
    FROM 
        [dbo].[LITA Capstone Dataset]
    GROUP BY 
        Product
)
-- Now select the results from the named "ProductRevenue"
SELECT * FROM ProductRevenue;


	-- Monthly sales totals for the current year using a WITH clause
WITH MonthlySales AS (
    SELECT 
        MONTH(OrderDate) AS Month,
        SUM(CAST(Quantity AS DECIMAL(18, 2)) * CAST(UnitPrice AS DECIMAL(18, 2))) AS TotalSales
    FROM 
        [dbo].[LITA Capstone Dataset]
    WHERE 
        YEAR(OrderDate) = YEAR(GETDATE())  -- Filter for the current year
    GROUP BY 
        MONTH(OrderDate)
)
-- Now select the results from the named "MonthlySales"
SELECT * FROM MonthlySales;


-- Top 5 customers by total purchase amount using WITH clause
WITH CustomerPurchases AS (
    SELECT 
        [Customer_Id],
        SUM(CAST(Quantity AS DECIMAL(18, 2)) * CAST(UnitPrice AS DECIMAL(18, 2))) AS TotalPurchaseAmount
    FROM 
        [dbo].[LITA Capstone Dataset]
    GROUP BY 
        [Customer_Id]
)
-- Now select the top 5 customers from the named "CustomerPurchases"
SELECT TOP 5 * 
FROM CustomerPurchases
ORDER BY TotalPurchaseAmount DESC;


-- Calculate percentage of total sales by region using WITH clause
WITH RegionalSales AS (
    SELECT 
        Region,
        SUM(CAST(Quantity AS DECIMAL(18, 2)) * CAST(UnitPrice AS DECIMAL(18, 2))) AS TotalSales
    FROM 
        [dbo].[LITA Capstone Dataset]
    GROUP BY 
        Region
),
TotalSales AS (
    SELECT 
        SUM(CAST(Quantity AS DECIMAL(18, 2)) * CAST(UnitPrice AS DECIMAL(18, 2))) AS OverallTotalSales
    FROM 
        [dbo].[LITA Capstone Dataset]
)
-- Now calculate the percentage of total sales by region
SELECT 
    R.Region,
    R.TotalSales,
    (R.TotalSales / T.OverallTotalSales) * 100 AS SalesPercentage
FROM 
    RegionalSales R, TotalSales T;

-- Identify products with no sales in the last quarter using WITH clause
WITH LastQuarter AS (
    SELECT 
        Product
    FROM 
        [dbo].[LITA Capstone Dataset]
    WHERE 
        OrderDate >= DATEADD(MONTH, -3, GETDATE())  -- Last 3 months
    GROUP BY 
        Product
),
AllProducts AS (
    SELECT DISTINCT Product
    FROM [dbo].[LITA Capstone Dataset]
)
-- Now select products not in the last quarter sales
SELECT 
    A.Product
FROM 
    AllProducts A
LEFT JOIN 
    LastQuarter LQ ON A.Product = LQ.Product
WHERE 
    LQ.Product IS NULL;
